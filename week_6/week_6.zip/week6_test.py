import importlib
import unittest

week6 = importlib.import_module('6210545955_lab6')

# (input, expected_output)
# python -m unittest -v test_module.py
# py -m doctest -v file.py


class Week6Test(unittest.TestCase):
    def test_1_ll_sum_normal_case(self):
        """----- normal Test 1 ll_sum(lst: list) -> list"""
        self.assertEqual(week6.ll_sum([[1, 2], [3], [4, 5, 6]]), 21)
        self.assertEqual(week6.ll_sum([[0], [0], [0]]), 0)
        self.assertEqual(week6.ll_sum([[120359840]]), 120359840)

    def test_1_ll_sum_sensitive_case(self):
        """*** [Sensitive case] Test 1"""
        self.assertEqual(week6.ll_sum([[], [], []]), 0)
        self.assertEqual(week6.ll_sum([]), 0)

    def test_2_cumulative_sum_return_new_list(self):
        """----- return new lst Test 2 cumulative_sum(lst: list) -> list"""
        t = [1, 2, 3]
        self.assertEqual(week6.cumulative_sum(t), [1, 3, 6])
        self.assertEqual(t, [1, 2, 3])

    @unittest.expectedFailure
    def test_2_cumulative_sum_modify_list_sf(self):
        """(Should fail) Test 2"""
        t = [1, 2, 3]
        week6.cumulative_sum(t)
        self.assertEqual(t, [1, 3, 6])

    def test_2_cumulative_sum_normal_case(self):
        """----- normal Test 2 cumulative_sum(lst: list) -> list"""
        self.assertEqual(week6.cumulative_sum([1, 2, 3]), [1, 3, 6])
        self.assertEqual(week6.cumulative_sum([1, 1, 1, 1, 1]), [1, 2, 3, 4, 5])
        self.assertEqual(week6.cumulative_sum([0, 0, 0]), [0, 0, 0])
        # self.assertEqual(week6.cumulative_sum([-1, -2, -3]), [-1, -3, -6])
        self.assertEqual(week6.cumulative_sum([-1, -2, 3]), [-1, -3, 0])
        self.assertEqual(week6.cumulative_sum([1.2568, 0, 0]), [1.2568, 1.2568, 1.2568])

    def test_2_cumulative_sum_sensitive_case(self):
        """*** [Sensitive case] Test 2"""
        self.assertEqual(week6.cumulative_sum([]), [])

    def test_3_middle_return_new_list(self):
        """----- return new list Test 3 middle(lst: list) -> list"""
        t = [1, 2, 3, 4]
        self.assertEqual(week6.middle(t), [2, 3])
        self.assertEqual(t, [1, 2, 3, 4])

    @unittest.expectedFailure
    def test_3_middle_modify_list_sf(self):
        """(Should fail) Test 3 """
        t = [1, 2, 3, 4]
        week6.middle(t)
        self.assertEqual(t, [2, 3])

    def test_3_middle_normal_case(self):
        """----- normal Test 3 middle(lst: list) -> list"""
        self.assertEqual(week6.middle(['b', 'a', 'n', 'a', 'n', 'a']), ['a', 'n', 'a', 'n'])
        self.assertEqual(week6.middle([1.02684, -5658, 0.00, 4]), [-5658, 0.0])
        self.assertEqual(week6.middle(['b', 'a', 5, 'n', 940, 'a', 'n', 'a']), ['a', 5, 'n', 940, 'a', 'n'])

    def test_3_middle_sensitive_case(self):
        """*** [Sensitive case] Test 3"""
        self.assertEqual(week6.middle([1]), [1])
        self.assertEqual(week6.middle([]), [])

    def test_4_chop_modify_list(self):
        """----- modify list Test 4 chop(lst: list) -> None remove first and last elements"""
        # modify list, return None
        t = [1, 2, 3, 4]
        # self.assertEqual(week6.chop(t), None)
        week6.chop(t)
        self.assertEqual(t, [2, 3])

    @unittest.expectedFailure
    def test_4_chop_return_new_list_sf(self):
        """(Should fail) Test 4"""
        self.assertEqual(week6.chop([1, 2, 3, 4]), [2, 3])

    def test_4_chop_normal_case(self):
        """----- normal Test 4 chop(lst: list) -> None remove first and last elements"""
        t = ['b', 'a', 'n', 'a', 'n', 'a']
        week6.chop(t)
        self.assertListEqual(t, ['a', 'n', 'a', 'n'])

        t = [1.02684, -5658, 0.00, 4]
        week6.chop(t)
        self.assertEqual(t, [-5658, 0.00])

        t = ['b', 'a', 5, 'n', 940, 'a', 'n', 'a']
        week6.chop(t)
        self.assertEqual(t, ['a', 5, 'n', 940, 'a', 'n'])

    def test_4_chop_sensitive_case(self):
        """*** [Sensitive_case] Test 4"""
        t = [1, 2]
        week6.chop(t)
        self.assertEqual(t, [])

    def test_5_is_sorted_normal_case(self):
        """----- normal Test 5 is_sorted(lst: list) -> bool sort in ascending order"""
        # True
        self.assertTrue(week6.is_sorted([1, 2, 2]))
        self.assertTrue(week6.is_sorted(['b', 'b', 'b']))
        self.assertTrue(week6.is_sorted([1]))

        # False
        self.assertFalse(week6.is_sorted(['b', 'a']))
        self.assertFalse(week6.is_sorted([59981, -1]))
        self.assertFalse(week6.is_sorted([4817987987, 187187, 547000000000000]))

    def test_5_is_sorted_sensitive_case(self):
        """*** [Sensitive case] Test 5"""
        self.assertTrue(week6.is_sorted([]))

    def test_6_front_x_return_new_list(self):
        """--*-- (P) return new list Test 6 front_x(lst: list) -> list"""
        # should return a new list
        t = ['mix', 'xyz', 'apple', 'xanadu', 'aardvark']
        self.assertEqual(week6.front_x(t), ['xanadu', 'xyz', 'aardvark', 'apple', 'mix'])
        self.assertEqual(t, ['mix', 'xyz', 'apple', 'xanadu', 'aardvark'])

    @unittest.expectedFailure
    def test_6_front_x_modify_list_sf(self):
        """(Should fail) Test 6"""
        t = ['mix', 'xyz', 'apple', 'xanadu', 'aardvark']
        week6.front_x(t)
        self.assertEqual(t, ['xanadu', 'xyz', 'aardvark', 'apple', 'mix'])

    def test_6_front_x_normal_case(self):
        """----- normal Test 6 front_x(lst: list) -> list"""
        # a question didn't say that you can't modify the original list
        self.assertEqual(week6.front_x(['x', 'xbbb', 'hg', 'a']), ['x', 'xbbb', 'a', 'hg'])
        self.assertEqual(week6.front_x(['a']), ['a'])
        self.assertEqual(week6.front_x(['x', 'xx', 'xxx']), ['x', 'xx', 'xxx'])

    def test_6_front_x_sensitive_case(self):
        """*** [Sensitive case] Test 6"""
        self.assertEqual(week6.front_x([]), [])

    def test_7_even_only_return_new_list(self):
        """----- return new list Test 7 even_only(lst: list) -> list"""
        t = [3, 1, 4, 1, 5, 9, 2, 6, 5]
        self.assertEqual(week6.even_only(t), [4, 2, 6])
        self.assertEqual(t, [3, 1, 4, 1, 5, 9, 2, 6, 5])

    @unittest.expectedFailure
    def test_7_even_only_modify_list_sf(self):
        """(Should fail) Test 7"""
        t = [3, 1, 4, 1, 5, 9, 2, 6, 5]
        week6.even_only(t)
        self.assertEqual(t, [4, 2, 6])

    def test_7_even_only_normal_case(self):
        """----- normal Test 7 even_only(lst: list) -> list : 0 is even"""
        # should return a new list
        t = [3, 1, 4, 1, 5, 9, 2, 6, 5]
        self.assertEqual(week6.even_only(t), [4, 2, 6])
        self.assertEqual(t, [3, 1, 4, 1, 5, 9, 2, 6, 5])

        self.assertEqual(week6.even_only([187145481841516875, 981987949, 2]), [2])
        self.assertEqual(week6.even_only([5, 5, 5, 5]), [])

        self.assertEqual(week6.even_only([0]), [0])

        self.assertEqual(week6.even_only([1]), [])

    def test_7_even_only_sensitive_case(self):
        """*** [Sensitive case] Test 7"""
        self.assertEqual(week6.even_only([]), [])

    def test_8_love_normal_case(self):
        """----- normal Test 8 love(s: str) -> str"""
        self.assertEqual(week6.love("I like Python"), "I love Python")
        self.assertEqual(week6.love("I really like Python"), "I really love Python")
        self.assertEqual(week6.love("x x x x x x x"), "x x x x x love x")
        self.assertEqual(week6.love("I hate"), "love hate")

    def test_8_love_sensitive_case(self):
        """*** [Sensitive case] Test 8"""
        # failed |
        self.assertEqual(week6.love("I"), "I")

        # failed |
        # self.assertEqual(week6.love(""), "")

        # failed |
        # self.assertEqual(week6.love(" "), " ")

    def test_9_is_anagram_normal_case(self):
        """----- normal Test 9 is_anagram(s1: str, s2: str) -> bool"""
        # example case
        self.assertTrue(week6.is_anagram("arrange", "Rear Nag"))

        # my case
        self.assertFalse(week6.is_anagram("dog", "cat"))
        self.assertTrue(week6.is_anagram("Dormitory", "Dirty room"))

    def test_9_is_anagram_special_case(self):
        """----- Test 9 is_anagram "ASTRONOMER" """
        # failed |
        self.assertFalse(week6.is_anagram('ASTRONOMER', 'MooN sTarREr'))

    def test_9_is_anagram_sensitive_case(self):
        """*** [Sensitive case] Test 9"""
        self.assertTrue(week6.is_anagram('', ''))
        self.assertTrue(week6.is_anagram(' ', ' '))

    def test_10_has_duplicates_not_modify_list(self):
        """----- not modify Test 10 has_duplicates(lst: list) -> bool"""
        # not modify original list
        t = [1, 2, 3, 4, 5, 2]
        week6.has_duplicates(t)
        self.assertEqual(t, [1, 2, 3, 4, 5, 2])

    def test_10_has_duplicates_normal_case(self):
        """----- normal Test 10 has_duplicates(lst: list) -> bool"""
        # self.assertTrue(week6.has_duplicates(['x', 'x', 'x']))

        self.assertFalse(week6.has_duplicates([1, 2, 3, 4, 5]))
        self.assertFalse(week6.has_duplicates([1]))
        # self.assertFalse(week6.has_duplicates(['A', 'a']))

    def test_10_has_duplicates_sensitive_case(self):
        """*** [Sensitive case] Test 10"""
        self.assertFalse(week6.has_duplicates([]))

    def test_11_average_normal_case(self):
        """----- normal Test 11 average(lst: list) -> float"""
        self.assertEqual(week6.average([1, 1, 5, 5, 10, 8, 7]), 5.285714285714286)
        self.assertEqual(week6.average([1, 2, 3, 2, 3, 0.2565985, 36, 4, 4215645855]), 468405100.6951776)
        self.assertEqual(week6.average([0]), 0)
        self.assertEqual(week6.average([1, 1, 1, 1, 1]), 1)

    def test_11_average_sensitive_case(self):
        """*** [Sensitive case] Test 11"""
        # failed |
        self.assertEqual(week6.average([]), 0)

    def test_12_centered_average_normal_case(self):
        """----- normal Test 12 centered_average(lst: list) -> float"""
        self.assertEqual(week6.centered_average([1, 1, 5, 5, 10, 8, 7]), 5.2)
        self.assertEqual(week6.centered_average([1, 1, 1, 1, 1, 1, 1, 1]), 1)
        # self.assertEqual(week6.centered_average([0, 0.1, 5]),  0.09999999999999964)     # 0.1

    def test_12_centered_average_sensitive_case(self):
        """*** [Sensitive case] Test 12"""
        # failed |
        self.assertEqual(week6.centered_average([]), 0)

    def test_13_reverse_pair_normal_case(self):
        """----- normal Test 13 reverse_pair(s: str) -> str"""
        self.assertEqual(week6.reverse_pair("May the fourth be with you"), "you with be fourth the May")
        self.assertEqual(week6.reverse_pair("x y zz"), "zz y x")
        self.assertEqual(week6.reverse_pair("May"), "May")

    def test_13_reverse_pair_sensitive_case(self):
        """*** [Sensitive case] Test 13"""
        self.assertEqual(week6.reverse_pair(""), "")
        self.assertEqual(week6.reverse_pair(" "), " ")

    def test_14_match_ends_normal_case(self):
        """----- normal Test 14 match_ends(lst: list) -> int"""
        self.assertEqual(week6.match_ends(["Gingering", "hello", "wow"]), 2)
        self.assertEqual(week6.match_ends(["Aa", "aA", "aa", "AA"]), 4)
        self.assertEqual(week6.match_ends(["mo", "Om"]), 0)

    def test_15_remove_adjacent_return_new_list(self):
        """--*-- return new list Test 15 remove_adjacent(lst:list) -> list"""
        t = [1, 2, 2, 3]
        self.assertEqual(week6.remove_adjacent(t), [1, 2, 3])
        self.assertEqual(t, [1, 2, 2, 3])

    @unittest.expectedFailure
    def test_15_remove_adjacent_modify_list_sf(self):
        """--*-- (Should fail) Test 15 remove_adjacent(lst:list) -> list"""
        t = [1, 2, 2, 3]
        week6.remove_adjacent(t)
        self.assertEqual(t, [1, 2, 3])

    def test_15_remove_adjacent_normal_case(self):
        """----- normal Test 15 remove_adjacent(lst:list) -> list"""
        self.assertEqual(week6.remove_adjacent([1, 2, 2, 3]), [1, 2, 3])
        # self.assertEqual(week6.remove_adjacent([0, 0, 0, 0]), [0])
        self.assertEqual(week6.remove_adjacent([1.0, 1, 2, 3]), [1, 2, 3])
        self.assertEqual(week6.remove_adjacent([-4, 4, 2]), [-4, 4, 2])

    def test_15_remove_adjacent_sensitive_case(self):
        """*** [Sensitive case] [1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 3] Test 15"""
        self.assertEqual(week6.remove_adjacent([1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 3]), [1, 2, 3])


if __name__ == '__main__':
    unittest.main(verbosity=2)
